-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Jeu 18 Février 2021 à 22:28
-- Version du serveur :  5.7.14
-- Version de PHP :  5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `bdcamundatest`
--

-- --------------------------------------------------------

--
-- Structure de la table `conges`
--

CREATE TABLE `conges` (
  `id` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(200) NOT NULL,
  `services` varchar(150) NOT NULL,
  `poste` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL,
  `jours` int(2) NOT NULL,
  `datedepart` date NOT NULL,
  `statut` varchar(30) NOT NULL,
  `uploadfile` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `conges`
--

INSERT INTO `conges` (`id`, `nom`, `prenom`, `services`, `poste`, `email`, `jours`, `datedepart`, `statut`, `uploadfile`) VALUES
(33, 'TRAORE', 'OBONAN ETIENNE', 'SOCECI', 'STAGIAIRE', 'dekamille@gmail.com', 12, '2021-02-23', 'ACCORDE', 'fichiers/1613671979-log.PNG'),
(34, 'TRAORE', 'OBONAN', 'INFORMATIQUE', 'INTEGRATEUR', 'etiobotra@gmail.com', 5, '2021-03-13', 'ACCORDE', 'fichiers/1613672646-abonnementbranchement.png'),
(35, 'KAMATE', 'ALMAMI', 'DAPSI', 'CRECHERCHE', 'etiobotra@gmail.com', 4, '2021-02-26', 'REFUSE', 'fichiers/1613673001-216.png'),
(36, 'SANOGO', 'ABOUBACAR', 'INFORMATIQUE', 'INTEGRATEUR', 'etiobotra@gmail.com', 13, '2021-02-26', 'ACCORDE', 'fichiers/1613673030-abonnementbranchement.png'),
(37, 'datoliban', 'anicet yves', 'DRH', 'INTEGRATEUR', 'dato@gmail.com', 13, '2021-02-16', 'ACCORDE', 'fichiers/1613679445-log.PNG'),
(38, 'TRAORE', 'OBONAN', 'INFORMATIQUE', 'STAGIAIRE', 'etiobotra@gmail.com', 4, '2021-02-24', 'REFUSE', 'fichiers/1613679393-abonnementbranchement.png'),
(39, 'TRAORE', 'OBONAN', 'INFORMATIQUE', 'STAGIAIRE', 'etiobotra@gmail.com', 4, '2021-02-24', 'REFUSE', 'fichiers/1613679393-abonnementbranchement.png'),
(40, 'N\'DJA', 'ismaÃªl', 'INFORMATIQUE', 'INTEGRATEUR', 'ismoto@gmail.com', 13, '2021-02-23', 'REFUSE', 'fichiers/1613679936-213.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `nom_utilisateur` varchar(100) NOT NULL,
  `mot_de_passe` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `utilisateur`
--

INSERT INTO `utilisateur` (`nom_utilisateur`, `mot_de_passe`) VALUES
('eti', '123'),
('ete', '123');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `conges`
--
ALTER TABLE `conges`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `conges`
--
ALTER TABLE `conges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
