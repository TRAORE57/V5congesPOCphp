<?php

function saveToDatabase($data=[]) {
    //ouverture de la ase et connexion 
    $objetPDO = new PDO ('mysql:host=localhost; dbname=bdcamundatest','root','');
    // prepartion de la requête pou inserer les données dans la base (SQL)
    $PDOstart = $objetPDO->prepare('INSERT INTO conges VALUES (NULL,:nom, :prenom, :services, :poste, :email, :jours,:datedepart, :statut, :uploadfile)');
    //lier chaque marqueur à une valeur de la table
    $PDOstart ->bindValue(':nom',$data['nom'],PDO::PARAM_STR);
    $PDOstart ->bindValue(':prenom',$data['prenom'],PDO::PARAM_STR);
    $PDOstart ->bindValue(':services',$data['services'],PDO::PARAM_STR);
    $PDOstart ->bindValue(':poste',$data['poste'],PDO::PARAM_STR);
    $PDOstart ->bindValue(':email',$data['email'],PDO::PARAM_STR);
    $PDOstart ->bindValue(':jours',$data['jours'],PDO::PARAM_STR);
    $PDOstart ->bindValue(':datedepart',$data['datedepart'],PDO::PARAM_STR);
    $PDOstart ->bindValue(':statut',$data['statut'],PDO::PARAM_STR);
    $PDOstart ->bindValue(':uploadfile',$data['uploadfile'],PDO::PARAM_STR);
    // execution de la requete preparées
    return $PDOstart->execute();
}