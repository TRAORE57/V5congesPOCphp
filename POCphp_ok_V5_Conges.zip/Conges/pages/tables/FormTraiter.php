
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>E-Demande.CIE</title>
  <link rel="stylesheet" href="styl.css" />

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini">
  <div class="wrapper">

    <!-- bloque logo cie -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
      <!-- Brand Logo -->
      <a href="https://www.cie.ci/" class="brand-link">
        <img src="../../dist/img/AdminLTELogo.png" alt="Logo CIE" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">CIE | Congés</span>
      </a>

      <!-- Sidebar -->
      <div class="sidebar">
        <!-- Sidebar user (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
          <div class="image">
            <img src="../../dist/img/avatar5.png" class="img-circle elevation-2" alt="User Image">
          </div>
          <div class="info">
            <a href="#" class="d-block">Etienne Traoré</a>
          </div>
        </div>

        <!-- SidebarSearch Form -->
        <div class="form-inline">
          <div class="input-group" data-widget="sidebar-search">
            <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
            <div class="input-group-append">
              <button class="btn btn-sidebar">
                <i class="fas fa-search fa-fw"></i>
              </button>
            </div>
          </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <!-- Ajout d'element dans la palette gauche de la page-->
            <li class="nav-item">
              <ul class="nav nav-treeview">
            </li>
          </ul>
          </li>


          <li class="nav-item menu-open">

          <li class="nav-item">
            <a href="../tables/data.php" class="nav-link active">
              <i class="far fa-circle nav-icon"></i>
              <p>Voir les demandes</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="../tables/jsgrid.php" class="nav-link">
              <i class="far fa-circle nav-icon"></i>
              <p>Demandes Traitées</p>
            </a>
          </li>
          </ul>
          </li>

          </ul>
        </nav>
        <!-- /.sidebar-menu -->
      </div>
      <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1><strong>Demandes de congés</strong></h1>
            </div>
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <h2 class="card-title">
                    <strong> DEMANDE EN COURS DE VALIDATION</strong>
                    <!--  requete de recuperation des donnees depuis camunda -->
                    <?php
                    //ouverture de fichier une seule fois
                  require_once('camundaRestClient.php');

                  $restClient = new camundaRestClient('http://localhost:8080/engine-rest');
                  // recuperation de l'id de la tache 
                  $tacheId = $_GET['id'];

                  //recuperer les variables  de la tache en cours
                  $resul =$restClient->getProcessVariables($_GET['processInstanceId']);
                  //var_dump($resul);exit;
                   //$resul contient que les variable
                  $email = $resul->mail->value; 
                  //var_dump($resul->mail->value);
                    ?>
                  </h2>
                </div>
                <!-- TABLEAU DE DEMANDES EN COURS -->
                
                <div class="card-body">
                    
                	<form method="POST" action="Accorder.php?id=<?=$tacheId?>&email=<?=$email?>">
                  		<!-- ici le formulaire de verification -->
                  	<div class="mb-3 row">
            						<label for="inputPassword" class="col-sm-2 col-form-label">NOM</label>
            					<div class="col-sm-4">
        							     <input   readonly type="text"  name ="nom" value="<?=$resul->nom->value?>" class="form-control" id="nom">
      						    </div>
    						        <label for="inputPassword" class="col-sm-2 col-form-label">PRENOM</label>
    						      <div class="col-sm-4">
      							       <input readonly type="text" name ="prenom" class="form-control" id="prenom" value="<?=$resul->prenom->value?>">
    						      </div>
    						        <label for="inputPassword" class="col-sm-2 col-form-label">POSTE</label>
    						      <div class="col-sm-4">
      							       <input readonly type="text"  name="poste" class="form-control" id="poste" value="<?=$resul->poste->value?>">
    						      </div>
    						        <label for="inputPassword" class="col-sm-2 col-form-label">SERVICE</label>
    						      <div class="col-sm-4">
      							       <input  readonly type="text"  name="service" class="form-control" id="service" value="<?=$resul->service->value?>">
    						      </div>
                        <label for="inputPassword" class="col-sm-2 col-form-label">E-MAIL</label>
                      <div class="col-sm-4">
                           <input  readonly type="text"  name="email" class="form-control" id="email" value="<?=$resul->mail->value?>">
                     </div>
    						        <label for="NombreJours" class="col-sm-2 col-form-label">NOMBRE DE JOURS</label>
    						      <div class="col-sm-4">
      							       <input readonly type="number" name="jours" class="form-control" id="jours" value="<?=$resul->jours->value?>">
    						      </div>
    						        <label for="date" class="col-sm-2 col-form-label">DATE DE DEPART </label>
    						      <div class="col-sm-4">
                           <input readonly type="text" name="datedepart" class="form-control" id="datedepart" value="<?=$resul->DateDepart->value?>">
    						      </div>
    						      <div class="d-grid gap-4 d-md-flex justify-content-md-end">
                           <input readonly type="hidden" name="uploadfile"  class="form-control" id="piece" value="<?=$resul->uploadfile->value?>">
    						      </div>
    						      <div class="d-grid gap-4 d-md-flex justify-content-md-end">
        						      <button   class="btn btn-outline-success" type="submit" class="btn btn-success" name="accorder"><strong>ACCORDER</strong></button>
        						      <a  class="btn btn-outline-danger" href="motifConge.php?tacheId=<?=$tacheId?>&mail=<?=$email?>&nom=<?=$resul->nom->value?>& prenom=<?=$resul->prenom->value?>&poste=<?=$resul->poste->value?>&service=<?=$resul->service->value?>&jours=<?=$resul->jours->value?>&datedepart=<?=$resul->DateDepart->value?>&uploadfile=<?=$resul->uploadfile->value?>"><strong>REFUSER</strong></a>
                          
                        </div>
                    </div>
                	</form>
                </div>
                <!-- /.card-body -->
              </div>
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
      </section>
      <!-- /.content -->
    </div>
 
    <!-- pieds de page -->
    <footer class="main-footer">
      <div class="float-right d-none d-sm-block">
        <b>Version</b> 1.0.0
      </div>
      <strong>Copyright &copy; 2014-2021 <a href="hhttps://www.cie.ci/">CIE-GS2E</a>.</strong> Tous droits reservés
    </footer>
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="../../plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- DataTables  & Plugins -->
  <script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
  <script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
  <script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
  <script src="../../plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
  <script src="../../plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script src="../../plugins/jszip/jszip.min.js"></script>
  <script src="../../plugins/pdfmake/pdfmake.min.js"></script>
  <script src="../../plugins/pdfmake/vfs_fonts.js"></script>
  <script src="../../plugins/datatables-buttons/js/buttons.html5.min.js"></script>
  <script src="../../plugins/datatables-buttons/js/buttons.print.min.js"></script>
  <script src="../../plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../../dist/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="../../dist/js/demo.js"></script>
  <!-- Page specific script -->
  <script>
    $(function() {
      $("#example1").DataTable({
        "responsive": true,
        "lengthChange": false,
        "autoWidth": false,
        "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
      }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "responsive": true,
      });
    });

  </script>
</body>

</html>