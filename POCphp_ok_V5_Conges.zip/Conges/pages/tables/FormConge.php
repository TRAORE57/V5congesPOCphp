
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Demande de conges</title>
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="container">
    <div class="title">DEMANDE DE CONGES</div>
    <div class="content">
      <form action="SoumettreConge.php" method="POST" enctype='multipart/form-data' >
        <div class="user-details">
          <div class="input-box">
            <span class="details">Nom</span>
            <input type="text" name="nom" placeholder="Entrer le nom" required>
          </div>
          <div class="input-box">
            <span class="details">Prénom(s)</span>
            <input type="text" name="prenom" placeholder="Entrer le(s) prénom(s)" required>
          </div>
             <div class="input-box">
            <span class="details">E-mail</span>
            <input type="text" placeholder="E-mail" name="mail" required>
          </div>
          <div class="select-box">
            <span class="details">Service</span>
            <!--<input type="file" name="service" placeholder="Entrer le service" required>-->
            <select name="service" id="service">
              <option value="">Selectionnez le service</option>
              <option value="INFORMATIQUE">INFORMATIQUE</option>
              <option value="DAPSI">DAPSI</option>
              <option value="DIT">DIT</option>
              <option value="DPI">DPI</option>
              <option value="DRH">DRH</option>
              <option value="SOCECI">SOCECI</option>
              <option value="GS2E">GS2E</option>
              <option value="CIE">CIE</option>
            </select>
          </div>
          <div class="input-box">
            <span class="details">Votre pièce</span>
            <input type="file" name="pieceJointe" required>
          </div>
          
          <div class="input-box">
            <span class="details">Poste</span>
            <input type="text" placeholder="Entrer le poste" name="poste" required>
          </div>
          <div class="input-box">
            <span class="details">Nombre de jours</span>
            <input type="number" min="1" placeholder="Saisir nombre de jour"  name="jours" required>
          </div>
          <div class="input-box">
            <span class="details">Date de depart</span>
            <input type="date" placeholder="Inserer la date de départ" name="DateDepart" required>
          </div>
        </div>
        <div class="button"> 
          <input type="submit" value="Envoyer">
        </div>
      </form>
    </div>
  </div>

</body>
</html>
