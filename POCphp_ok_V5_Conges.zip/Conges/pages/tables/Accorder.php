<?php
// chargement de la fonction d'insertion
require_once 'saveToDatabase.php'; 
//enregistrement en base
$isSave = saveToDatabase(array(
    'statut'=> 'ACCORDE',
    'nom'=>$_POST['nom'],
    'prenom'=>$_POST['prenom'],
    'services'=>$_POST['service'],
    'poste'=>$_POST['poste'], 
    'jours'=>$_POST['jours'],
    'datedepart'=>$_POST['datedepart'],
    'email'=>$_POST['email'],
    'uploadfile'=>$_POST['uploadfile']
));
// verification de l'envoi des données en base 
if($isSave){
    echo 'enregistré';
}else{
    echo "probleme d'enregistrement dans la base de donnée";
}


//id de la tache
$tacheId = $_GET['id'];
require_once('camundaRestClient.php');
$restClient = new camundaRestClient('http://localhost:8080/engine-rest');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/vendor/phpmailer/src/Exception.php';
require_once __DIR__ . '/vendor/phpmailer/src/PHPMailer.php';
require_once __DIR__ . '/vendor/phpmailer/src/SMTP.php';

//passer true dans le constructeur, active les exceptions dans PHPMailer
$mail = new PHPMailer(true);

try {
    // configuration serveur 
    $mail->SMTPDebug = SMTP::DEBUG_SERVER; // pour les details de debeugage
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->Username = 'etiobotra@gmail.com'; // mon  email de gmail
    $mail->Password = 'PAPAthio57.'; // mon mot de passe gmail

    // Paramètres de l'expéditeur et du destinataire
    $mail->setFrom('etiobotra@gmail.com', "TRAORE "); //expediteur
    $mail->addAddress('etiobotra@gmail.com', 'TRAORE OBONAN ');
    $mail->addReplyTo('etiobotra@gmail.com', "TRAORE OBONAN ETIENNE"); // to set the reply to

    // Setting the email content
    $mail->IsHTML(true);
    $mail->Subject = "AVIS DU RESPONSABLE";
    $mail->Body = 'VOTRE DEMANDE DE CONGE A ETE ACCORDE';
    $mail->AltBody = 'Plain text message body for non-HTML email client. Gmail SMTP email body.';

    $mail->send();
    echo "Message électronique envoyé.";
} catch (Exception $e) {
    echo "Erreur lors de l'envoi du courrier électronique. Erreur de l'expéditeur: {$mail->ErrorInfo}";
}
//tachevement de la tâche ou de la soumission de la demande 
//parametre et nom de celui qui est sensé terminer la tache
$params= [ 
	"variables"=>[
		"approver"=>[ 
			"value"=>'demo',
			"type"=>'string'
		]
	]
];
// appel de la fonction completeTask pour mettre fin a la tache
$fini =$restClient->completeTask($tacheId,$params);
//rediraction sr la page data.php
header('Location: data.php');


?>