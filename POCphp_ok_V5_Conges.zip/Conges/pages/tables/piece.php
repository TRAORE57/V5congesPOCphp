<div class="container">
    <div class="title">VERIFICATION DE PIECE</div>
        <div class="content">

            <?php 
            //ouverture d'une connexion à la base de données test 
            $objetPDO = new PDO ('mysql:host=localhost; dbname=bdcamundatest','root','');
            //prepâration de la requete de recuperation des donnees de la bd
            $PDOstart = $objetPDO->prepare('SELECT uploadfile FROM conges LIMIT 1' );
            //execution de la requete
            $recuperation=$PDOstart->execute();
            //recuperation de tous  les conges dans la table conges
            ///$conges =$PDOstart->fetch();
            $conges =$PDOstart->fetch();
            $chemin=$conges['uploadfile'];
            //var_dump($chemin);exit;

            ?>  
            <img src="<?=$_GET['piece']?>" >
        </div>
    </div>
 </div>